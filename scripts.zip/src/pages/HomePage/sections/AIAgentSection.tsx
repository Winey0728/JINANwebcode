import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MessageCircle,
  Volume2,
  MapPin,
  Image as ImageIcon,
  X,
  Send,
  Play,
  Pause,
  Loader2,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { capabilityClient, logger } from '@lark-apaas/client-toolkit-lite';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { MOCK_CULTURAL_RESOURCES } from '@/data/culturalresources';
import { Image } from '@/components/ui/image';

const QA_PLUGIN_ID = 'jinan_water_culture_qa_agent_1';
const ROUTE_PLUGIN_ID = 'jinan_culture_tour_route_planner_1';
const SPEECH_PLUGIN_ID = 'jinan_attractions_speech_synthesis_1';

const aiFeatures = [
  {
    id: 'qa',
    icon: MessageCircle,
    title: '文化问答',
    description: '智能解答济南泉水、名士、历史等文化相关问题',
    color: 'from-cyan-500 to-teal-500',
    bgColor: 'bg-cyan-50',
  },
  {
    id: 'speech',
    icon: Volume2,
    title: '语音讲解',
    description: 'AI语音合成，为景点提供专业的文化解说',
    color: 'from-blue-500 to-cyan-500',
    bgColor: 'bg-blue-50',
  },
  {
    id: 'route',
    icon: MapPin,
    title: '路线规划',
    description: '根据兴趣和时间，生成个性化游览路线',
    color: 'from-teal-500 to-emerald-500',
    bgColor: 'bg-teal-50',
  },
  {
    id: 'history',
    icon: ImageIcon,
    title: '历史复原',
    description: '古今对比，直观感受城市历史变迁',
    color: 'from-amber-500 to-orange-500',
    bgColor: 'bg-amber-50',
  },
];

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export default function AIAgentSection() {
  const [activeDialog, setActiveDialog] = useState<string | null>(null);

  return (
    <section id="ai-agent" className="w-full py-20 md:py-28 bg-gradient-to-b from-background to-cyan-50/30">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-cyan-600 font-medium text-sm tracking-widest mb-3">
            AI INTELLIGENCE
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            AI 智能体
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            人工智能赋能文化探索，让千年文化更加生动可感
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {aiFeatures.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -6, transition: { duration: 0.2 } }}
                onClick={() => setActiveDialog(feature.id)}
                className="group cursor-pointer bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl border border-border/50 transition-all duration-300"
              >
                <div className={`w-14 h-14 rounded-xl ${feature.bgColor} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`w-7 h-7 bg-gradient-to-br ${feature.color} bg-clip-text text-transparent`} style={{ WebkitTextFillColor: 'transparent', backgroundClip: 'text' }} />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                <div className="mt-4 text-cyan-600 text-sm font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  立即体验
                  <Sparkles className="w-4 h-4" />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* 问答对话框 */}
        <QADialog open={activeDialog === 'qa'} onOpenChange={(open) => !open && setActiveDialog(null)} />
        {/* 语音讲解对话框 */}
        <SpeechDialog open={activeDialog === 'speech'} onOpenChange={(open) => !open && setActiveDialog(null)} />
        {/* 路线规划对话框 */}
        <RouteDialog open={activeDialog === 'route'} onOpenChange={(open) => !open && setActiveDialog(null)} />
        {/* 历史复原对话框 */}
        <HistoryDialog open={activeDialog === 'history'} onOpenChange={(open) => !open && setActiveDialog(null)} />
      </div>
    </section>
  );
}

// === 文化问答 ===
function QADialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: '你好！我是济南水系文化智能问答助手，可以回答你关于济南泉水、名士、历史文化等方面的问题。请问有什么想了解的吗？' },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userQuestion = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', content: userQuestion }]);
    setIsLoading(true);

    try {
      const executor = (capabilityClient as any).load(QA_PLUGIN_ID);
      const stream = (executor as any).callStream('textGenerate', {
        user_question: userQuestion,
      });

      let fullContent = '';
      setMessages((prev) => [...prev, { role: 'assistant', content: '' }]);

      for await (const chunk of stream) {
        const piece = chunk.content ?? chunk.response;
        if (piece) {
          fullContent += piece;
          setMessages((prev) => {
            const newMessages = [...prev];
            newMessages[newMessages.length - 1] = { role: 'assistant', content: fullContent };
            return newMessages;
          });
        }
      }
    } catch (error) {
      logger.error('QA plugin error:', String(error));
      toast.error('智能问答服务暂不可用，请稍后再试');
      setMessages((prev) => [...prev, { role: 'assistant', content: '抱歉，智能问答服务暂时不可用，请稍后再试。' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] flex flex-col p-0">
        <DialogHeader className="px-6 py-4 border-b">
          <DialogTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-cyan-600" />
            文化问答智能体
          </DialogTitle>
          <DialogDescription>
            关于济南泉水、名士、历史文化的问题都可以问我
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[300px]">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                msg.role === 'user'
                  ? 'bg-cyan-500 text-white rounded-br-md'
                  : 'bg-muted text-foreground rounded-bl-md'
              }`}>
                {msg.role === 'assistant' ? (
                  <div className="prose prose-sm max-w-none dark:prose-invert">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content || '思考中...'}</ReactMarkdown>
                  </div>
                ) : (
                  <p className="text-sm">{msg.content}</p>
                )}
              </div>
            </div>
          ))}
          {isLoading && messages[messages.length - 1]?.role === 'user' && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3">
                <Loader2 className="w-5 h-5 animate-spin text-cyan-600" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSubmit} className="p-4 border-t flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="输入你的问题..."
            disabled={isLoading}
          />
          <Button type="submit" disabled={isLoading || !input.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// === 语音讲解 ===
function SpeechDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [selectedSpot, setSelectedSpot] = useState('');
  const [audioUrl, setAudioUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const springResources = MOCK_CULTURAL_RESOURCES.filter((r) => r.category === 'spring');

  const handleGenerate = async () => {
    if (!selectedSpot) {
      toast.info('请先选择一个景点');
      return;
    }
    const spot = springResources.find((r) => r.id === selectedSpot);
    if (!spot) return;

    setIsLoading(true);
    setAudioUrl('');
    setIsPlaying(false);
    setProgress(0);

    try {
      const executor = (capabilityClient as any).load(SPEECH_PLUGIN_ID);
      const result = await (executor as any).call('speechSynthesis', {
        introduction_text: `${spot.name}，${spot.description}。${spot.era ? '始建于' + spot.era + '。' : ''}济南七十二名泉之一，是泉城济南的重要文化名片。`,
      });
      if (result?.audioUrl) {
        setAudioUrl(result.audioUrl);
        toast.success('语音讲解已生成');
      }
    } catch (error) {
      logger.error('Speech plugin error:', String(error));
      toast.error('语音合成服务暂不可用');
    } finally {
      setIsLoading(false);
    }
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current && audioRef.current.duration) {
      setProgress((audioRef.current.currentTime / audioRef.current.duration) * 100);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-blue-600" />
            AI 语音讲解
          </DialogTitle>
          <DialogDescription>
            选择景点，生成专业的语音导览讲解
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label>选择景点</Label>
            <Select value={selectedSpot} onValueChange={setSelectedSpot}>
              <SelectTrigger>
                <SelectValue placeholder="请选择景点" />
              </SelectTrigger>
              <SelectContent>
                {springResources.map((spot) => (
                  <SelectItem key={spot.id} value={spot.id}>
                    {spot.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleGenerate} disabled={isLoading || !selectedSpot} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                生成中...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                生成语音讲解
              </>
            )}
          </Button>

          {audioUrl && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-3 p-4 bg-muted/50 rounded-xl"
            >
              <div className="flex items-center gap-3">
                <Button size="icon" variant="secondary" className="rounded-full w-12 h-12 shrink-0" onClick={togglePlay}>
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                </Button>
                <div className="flex-1">
                  <div className="text-sm font-medium text-foreground mb-1">
                    {springResources.find((r) => r.id === selectedSpot)?.name} 讲解
                  </div>
                  <Slider
                    value={[progress]}
                    max={100}
                    step={0.1}
                    onValueChange={(vals) => {
                      if (audioRef.current && audioRef.current.duration) {
                        audioRef.current.currentTime = (vals[0] / 100) * audioRef.current.duration;
                        setProgress(vals[0]);
                      }
                    }}
                  />
                </div>
              </div>
              <audio
                ref={audioRef}
                src={audioUrl}
                onTimeUpdate={handleTimeUpdate}
                onEnded={() => setIsPlaying(false)}
              />
            </motion.div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// === 路线规划 ===
function RouteDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [interests, setInterests] = useState('');
  const [time, setTime] = useState('');
  const [requirements, setRequirements] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!interests || !time) {
      toast.info('请填写兴趣方向和可用时间');
      return;
    }

    setIsLoading(true);
    setResult('');

    try {
      const executor = (capabilityClient as any).load(ROUTE_PLUGIN_ID);
      const stream = (executor as any).callStream('textGenerate', {
        user_interests: interests,
        available_time: time,
        additional_requirements: requirements || '无',
      });

      let full = '';
      for await (const chunk of stream) {
        const piece = chunk.content ?? chunk.response;
        if (piece) {
          full += piece;
          setResult(full);
        }
      }
    } catch (error) {
      logger.error('Route plugin error:', String(error));
      toast.error('路线规划服务暂不可用');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-teal-600" />
            个性化路线规划
          </DialogTitle>
          <DialogDescription>
            根据你的兴趣和时间，定制专属济南文化之旅
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>兴趣方向</Label>
              <Select value={interests} onValueChange={setInterests}>
                <SelectTrigger>
                  <SelectValue placeholder="选择兴趣" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="泉水文化">泉水文化</SelectItem>
                  <SelectItem value="历史古迹">历史古迹</SelectItem>
                  <SelectItem value="名士文化">名士文化</SelectItem>
                  <SelectItem value="美食体验">美食体验</SelectItem>
                  <SelectItem value="民俗非遗">民俗非遗</SelectItem>
                  <SelectItem value="综合体验">综合体验</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>可用时间</Label>
              <Select value={time} onValueChange={setTime}>
                <SelectTrigger>
                  <SelectValue placeholder="选择时间" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="半天">半天（4小时）</SelectItem>
                  <SelectItem value="1天">1天</SelectItem>
                  <SelectItem value="2天">2天</SelectItem>
                  <SelectItem value="周末">周末（2天1夜）</SelectItem>
                  <SelectItem value="3天">3天及以上</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>其他需求（可选）</Label>
            <Input
              value={requirements}
              onChange={(e) => setRequirements(e.target.value)}
              placeholder="如：亲子友好、少走路、公共交通出行等"
            />
          </div>

          <Button onClick={handleGenerate} disabled={isLoading || !interests || !time} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                规划中...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                生成路线方案
              </>
            )}
          </Button>

          {result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-muted/50 rounded-xl max-h-[400px] overflow-y-auto"
            >
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{result}</ReactMarkdown>
              </div>
            </motion.div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// === 历史复原 ===
function HistoryDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [sliderPos, setSliderPos] = useState(50);

  const handleSliderChange = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pos = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPos(pos);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-amber-600" />
            历史场景复原
          </DialogTitle>
          <DialogDescription>
            拖动滑块，对比济南的古今变迁
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div
            className="relative w-full aspect-[16/9] rounded-xl overflow-hidden cursor-ew-resize select-none"
            onMouseMove={(e) => e.buttons === 1 && handleSliderChange(e)}
            onMouseDown={handleSliderChange}
          >
            {/* 现代图（底层） */}
            <Image
              src="https://images.unsplash.com/photo-1537531383496-f4749b8032cf?w=800&h=450&fit=crop"
              alt="现代济南"
              className="absolute inset-0 w-full h-full object-cover"
              draggable={false}
            />
            {/* 历史图（上层，clip） */}
            <div
              className="absolute inset-0 overflow-hidden"
              style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
            >
              <Image
                src="https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&h=450&fit=crop"
                alt="老济南"
                className="absolute inset-0 w-full h-full object-cover sepia"
                draggable={false}
              />
            </div>
            {/* 滑块线 */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white shadow-lg"
              style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
            >
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-gray-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9 18l-6-6 6-6" />
                  <path d="M15 6l6 6-6 6" />
                </svg>
              </div>
            </div>
            {/* 标签 */}
            <div className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-black/50 backdrop-blur-sm text-white text-xs font-medium">
              老济南
            </div>
            <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-cyan-500/80 backdrop-blur-sm text-white text-xs font-medium">
              现代泉城
            </div>
          </div>

          <p className="text-sm text-muted-foreground text-center">
            拖动中间滑块，感受济南从古城到现代泉城的历史变迁
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
